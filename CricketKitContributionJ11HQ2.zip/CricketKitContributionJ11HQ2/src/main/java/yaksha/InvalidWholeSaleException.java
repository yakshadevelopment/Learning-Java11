package yaksha;

class InvalidWholeSaleException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidWholeSaleException(String msg) {
		super(msg);
	}
}
