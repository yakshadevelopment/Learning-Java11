package yaksha;

public class PanCard {
	private String panCard;

	public PanCard(String panCard) {
		super();
		this.panCard = panCard;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
}
